EIS run: mock
Date: 2026-10-22 12:58
Sweeps: 5
Frequencies: 20, from 1000 Hz to 100000 Hz
Sample rate: 500000 samples/s, 5000 samples per frequency
Calibration resistor: none

results/  impedance_<name>.csv  |Z| and phase per frequency for every sweep, plus mean, SD and CV
          cole_<name>.csv       Cole-Cole values per sweep, plus mean, SD, CV and the fit of the average
plots/    dashboard images
raw/      sweep_<name>_r<k>_<freq>Hz.csv  raw samples: time (s), ch0 (V, current), ch1 (V, voltage)
          cal_<name>_<freq>Hz.csv         calibration resistor samples (if used)
          cole_results.csv                running log of every fit on the board

To re-plot on a laptop: unzip the raw/ files next to pmod_dashboard.py, then
    python pmod_dashboard.py mock
